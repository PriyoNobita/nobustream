<?php
/**
 * StarStream IPTV – API Proxy v2
 * Compatible with InfinityFree, cPanel, shared hosting
 * Upload this alongside index.html — then channels will load!
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// CONFIG
define('S',  'http://starshare.st');
define('U',  'P4B9TB9xR8');
define('P',  'humongous2tonight');

$allowed = ['get_live_categories','get_live_streams','get_live_stream_info','get_short_epg_info'];
$action  = trim($_GET['action'] ?? '');
$catId   = trim($_GET['category_id'] ?? '');

if (!in_array($action, $allowed)) {
    http_response_code(400);
    die(json_encode(['error'=>'Bad action']));
}

$url = S.'/player_api.php?username='.U.'&password='.P.'&action='.urlencode($action);
if ($catId) $url .= '&category_id='.urlencode($catId);

// Simple file cache 5min
$cd = sys_get_temp_dir().'/ss_cache/';
if (!is_dir($cd)) @mkdir($cd,0755,true);
$cf = $cd.md5($url).'.json';
if (file_exists($cf) && time()-filemtime($cf)<300) {
    header('X-Cache: HIT');
    die(file_get_contents($cf));
}

$data = doFetch($url);
if ($data===false) {
    http_response_code(502);
    die(json_encode(['error'=>'Cannot reach IPTV server','url'=>$url,'hint'=>'Check if server '.S.' is online']));
}
@file_put_contents($cf,$data);
echo $data;

function doFetch($url) {
    // Try cURL first
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; StarStream/2.0)',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER     => ['Accept: application/json, */*'],
        ]);
        $r = curl_exec($ch);
        $c = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($r !== false && $c >= 200 && $c < 400) return $r;
    }
    // Fallback file_get_contents
    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http'=>[
            'timeout'=>25,'user_agent'=>'Mozilla/5.0 StarStream/2.0',
            'ignore_errors'=>true
        ],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
        $r = @file_get_contents($url,false,$ctx);
        if ($r !== false) return $r;
    }
    return false;
}
?>
