<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>StarStream – Server Test</title>
<style>
body{font-family:monospace;background:#0a0a14;color:#eee;padding:30px;max-width:700px;margin:0 auto;}
h2{color:#e50914;margin-bottom:20px;}
.ok{color:#22c55e;} .fail{color:#ef4444;} .warn{color:#f59e0b;}
.box{background:#111;border:1px solid #222;border-radius:8px;padding:16px;margin:12px 0;font-size:13px;line-height:1.8;}
pre{white-space:pre-wrap;word-break:break-all;color:#aaa;font-size:12px;margin-top:8px;}
</style>
</head>
<body>
<h2>🔧 StarStream Server Diagnostic</h2>

<?php
$server = 'http://starshare.st';
$user   = 'P4B9TB9xR8';
$pass   = 'humongous2tonight';
$url    = "$server/player_api.php?username=$user&password=$pass&action=get_live_categories";

echo '<div class="box">';
echo '<strong>PHP Version:</strong> '.phpversion().'<br>';
echo '<strong>cURL:</strong> '.(function_exists('curl_init') ? '<span class="ok">✅ Available</span>' : '<span class="fail">❌ Not available</span>').'<br>';
echo '<strong>allow_url_fopen:</strong> '.(ini_get('allow_url_fopen') ? '<span class="ok">✅ Enabled</span>' : '<span class="warn">⚠ Disabled</span>').'<br>';
echo '<strong>Test URL:</strong> '.htmlspecialchars($url).'<br>';
echo '</div>';

// Test cURL
if (function_exists('curl_init')) {
    echo '<div class="box"><strong>🔌 cURL Test:</strong><br>';
    $ch = curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,
        CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_USERAGENT=>'StarStream/2.0',
        CURLOPT_HTTPHEADER=>['Accept: application/json'],
    ]);
    $r = curl_exec($ch);
    $c = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $e = curl_error($ch);
    curl_close($ch);
    if ($r && $c == 200) {
        $j = json_decode($r, true);
        $cnt = is_array($j) ? count($j) : 0;
        echo '<span class="ok">✅ SUCCESS! HTTP '.$c.' – Got '.strlen($r).' bytes – '.$cnt.' categories found</span>';
        if ($cnt > 0) echo '<pre>First category: '.htmlspecialchars(json_encode($j[0])).'</pre>';
    } else {
        echo '<span class="fail">❌ FAILED! HTTP '.$c.' – Error: '.htmlspecialchars($e ?: 'Unknown').'</span>';
    }
    echo '</div>';
}

// Test file_get_contents
if (ini_get('allow_url_fopen')) {
    echo '<div class="box"><strong>📂 file_get_contents Test:</strong><br>';
    $ctx = stream_context_create(['http'=>['timeout'=>15,'user_agent'=>'StarStream/2.0']]);
    $r = @file_get_contents($url, false, $ctx);
    if ($r) {
        $j = json_decode($r, true);
        $cnt = is_array($j) ? count($j) : 0;
        echo '<span class="ok">✅ SUCCESS! Got '.strlen($r).' bytes – '.$cnt.' categories</span>';
    } else {
        echo '<span class="fail">❌ FAILED!</span>';
    }
    echo '</div>';
}

// Test api.php itself
echo '<div class="box"><strong>🧪 api.php self-test:</strong><br>';
$apiUrl = (isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?'https':'http').'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['REQUEST_URI']).'/api.php?action=get_live_categories';
echo 'api.php URL: '.htmlspecialchars($apiUrl).'<br>';
if (file_exists('api.php')) {
    echo '<span class="ok">✅ api.php exists on server</span><br>';
    // Try to call it
    if (function_exists('curl_init')) {
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>false]);
        $r = curl_exec($ch); $c = curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($r && $c==200) {
            $j = json_decode($r,true);
            $cnt = is_array($j)?count($j):0;
            echo '<span class="ok">✅ api.php works! '.$cnt.' categories returned</span>';
        } else {
            echo '<span class="fail">❌ api.php returned HTTP '.$c.'</span><pre>'.htmlspecialchars(substr($r,0,300)).'</pre>';
        }
    }
} else {
    echo '<span class="fail">❌ api.php NOT found – please upload it!</span>';
}
echo '</div>';

echo '<div class="box" style="color:#22c55e"><strong>✅ What to do next:</strong><br>';
echo '1. Make sure both <strong>index.html</strong> and <strong>api.php</strong> are in the same folder<br>';
echo '2. If cURL test above is ✅, everything should work<br>';
echo '3. Visit your site and channels should load automatically';
echo '</div>';
?>
</body>
</html>
